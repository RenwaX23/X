import sys
import re
import platform
import subprocess
import psutil
import os
import time

flag = f'file:///etc/WACON{{fake_fake_flag_flag}}'

def validate_url(url):
    pattern = r'^[a-zA-Z0-9\./]+$'
    return re.match(pattern, url)

def kill_existing_opera_processes():
    for process in psutil.process_iter(attrs=['pid', 'name']):
        if process.info['name'] == 'opera.exe' or process.info['name'] == 'Opera':
            try:
                psutil.Process(process.info['pid']).terminate()
            except psutil.NoSuchProcess:
                pass

def open_url(url):
    os_name = platform.system()

    kill_existing_opera_processes()

    script_directory = os.path.dirname(os.path.abspath(__file__))
    ext_path = os.path.join(script_directory, 'ext/')

    if os_name == 'Darwin':  
        try:
            subprocess.Popen(['open', '-a', 'Opera', '--args', '--load-extension=' + ext_path, '--new-tab', url, '--new-tab', flag])
        except Exception as e:
            print(f"Error opening URL: {e}")
    elif os_name == 'Windows':
        try:
            subprocess.Popen(['start', 'opera', '--load-extension=' + ext_path, '--new-tab', url, '--new-tab', flag], shell=True)
        except Exception as e:
            print(f"Error opening URL: {e}")
    elif os_name == 'Linux':
        try:
            subprocess.Popen(['opera', '--load-extension=' + ext_path, '--new-tab', url, '--new-tab', flag])
        except Exception as e:
            print(f"Error opening URL: {e}")
    else:
        print("Unsupported operating system. Please use macOS, Windows, or Linux.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <URL>")
        sys.exit(1)

    url = sys.argv[1]

    if not validate_url(url):
        print("Invalid URL")
        sys.exit(1)

    open_url(url)

    time.sleep(15)

    kill_existing_opera_processes()
