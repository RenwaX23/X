function safe(code) {
    document.write(`<iframe sandbox="allow-same-origin allow-scripts" srcdoc="<script src=&quot;${(code).replaceAll('&', 'X').replaceAll('"', "X")}&quot;></script>"></iframe>`)
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.message === "load") {

        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

            if(request.origin===tabs[0].url){
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: safe,
                args: [request.url],
            });
            }
        });

    }
});