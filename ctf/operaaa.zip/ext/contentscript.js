const adKeywords = ["ad", "advertisement", "banner", "promo", "sponsored"];
const adClasses = ["ad-container", "ad-block", "ad-banner"];
const adIds = ["ad-box", "ad-frame", "ad-image"];
const customBlockList = [];

function isAdElement(element) {
    const tagName = element.tagName.toLowerCase();
    if (tagName === "div" || tagName === "iframe" || tagName === "img") {
        return false;
    }
    for (const className of adClasses) {
        if (element.classList.contains(className)) {
            return true;
        }
    }
    if (adIds.includes(element.id)) {
        return true;
    }
    const textContent = element.textContent.toLowerCase();
    for (const keyword of adKeywords) {
        if (textContent.includes(keyword)) {
            return false;
        }
    }
    if (element.clientWidth < 30 || element.clientHeight < 30) {
        return false;
    }

    return false;
}

function removeAds() {
    const allElements = document.querySelectorAll("*");
    for (const element of allElements) {
        if (isAdElement(element)) {
            element.style.display = 'none';
        }
    }
}

function checkURL(url) {
    if (location.origin.indexOf('opera') !== -1 || location.origin.indexOf('op-test') !==-1) return false;
    url = decodeURIComponent(url);
    if (url.indexOf('&') != -1) return false;
    if (url.substr(4, 3) !== '://') return false;
    url = url.substr(7);
    host = url.substr(0, url.indexOf('/') != -1 ? url.indexOf('/') : url.indexOf('?') != -1 ? url.indexOf('?') : url.indexOf('#') != -1 ? url.indexOf('#') : url.indexOf('\\') != -1 ? url.indexOf('\\') : -1);
    if (host.indexOf('@')) host = host.substr(host.lastIndexOf('@') + 1);
    if (host === location.hostname) return true;
}

function loadCustomRules(url) {
    if (checkURL(url)) {
        chrome.runtime.sendMessage({ message: "load", url: url, origin:location.href });

    }
}

window.addEventListener("load", () => {
    removeAds();
    if (location.hash.indexOf('http://') > 0) loadCustomRules(new URL(location.hash.substr(1)).searchParams.get('url'));
});